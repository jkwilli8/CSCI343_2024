import { StatusBar } from "expo-status-bar";
import { StyleSheet, Text, View } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { useState } from "react";
import HomeScreen from "./screens/HomeScreen";
import MenuScreen from "./screens/MenuScreen";
import { useFonts } from "expo-font";
import { Colors } from "react-native/Libraries/NewAppScreen";

export default function App() {
  const [fontsloaded] = useFonts({
    zax: require("./assets/fonts/Zac.otf"),
  });

  // setting state variable for the current screen
  const [currentScreen, setCurrentScreen] = useState("Home");

  function menuScreenHandler() {
    setCurrentScreen("Menu");
  }

  function homeScreenHandler() {
    setCurrentScreen("Home");
  }

  // Determine which screen to be on.
  let screen = <HomeScreen onNext={menuScreenHandler} />;

  if (currentScreen === "Menu") {
    screen = <MenuScreen onNext={homeScreenHandler} />;
  }
  return (
    <>
      <StatusBar style="auto" />
      <SafeAreaProvider style={styles.container}>{screen}</SafeAreaProvider>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.primary500,
    alignItems: "center",
    justifyContent: "center",
  },
});
