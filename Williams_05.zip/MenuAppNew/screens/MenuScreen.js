import { View, StyleSheet, Text, FlatList } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import NavButton from "../components/NavButton";
import Title from "../components/Title";
import { useState } from "react";
import MenuItems from "../components/Menuitems";

function MenuScreen(props) {
  // Set Safe Area Screen Boundaries
  const insets = useSafeAreaInsets();

  const [menuItems, setMenuItems] = useState([
    {
      name: "Wings and Things",
      image: require("../assets/images/wnt.jpg"),
      price: "$14",
      id: 1,
    },
    {
      name: "Boneless Wings Meal",
      image: require("../assets/images/great8.jpg"),
      price: "$8",
      id: 2,
    },
    {
      name: "Nibler",
      image: require("../assets/images/nib.jpg"),
      price: "$4",
      id: 3,
    },
    {
      name: "Zalad",
      image: require("../assets/images/zal.jpg"),
      price: "$13",
      id: 4,
    },
    {
      name: "Big Zax Snack",
      image: require("../assets/images/bzs.jpg"),
      price: "$9",
      id: 5,
    },
  ]);

  return (
    <View
      style={[
        styles.rootContainer,
        {
          paddingTop: insets.top,
          paddingBottom: insets.bottom,
          paddingLeft: insets.left,
          paddingRight: insets.right,
        },
      ]}
    >
      <View style={styles.titleContainer}>
        <Title>Menu</Title>
      </View>

      <View style={styles.listContainer}>
        <FlatList
          data={menuItems}
          keyExtractor={(item) => item.id}
          alwaysBounceVertical={false}
          showsVerticalScrollIndicator={false}
          renderItem={(itemData) => {
            return (
              <MenuItems
                name={itemData.item.name}
                image={itemData.item.image}
                price={itemData.item.price}
              />
            );
          }}
        />
      </View>

      <View style={styles.buttonContainer}>
        <NavButton onPress={props.onNext}>View Events</NavButton>
      </View>
    </View>
  );
}

export default MenuScreen;

const styles = StyleSheet.create({
  rootContainer: {
    flex: 1,
    alignItems: "center",
  },
  titleContainer: {
    flex: 1,
    justifyContent: "center",
  },
  listContainer: {
    flex: 7,
    width: 300,
  },
  buttonContainer: {
    flex: 1,
  },
});
