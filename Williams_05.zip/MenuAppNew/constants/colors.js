const Colors = {
  accent300: "#f0001f",
  accent500: "#051f40",
  primary500: "#71797E",
};

export default Colors;
