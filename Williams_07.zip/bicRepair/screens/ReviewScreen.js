import { StyleSheet, Text, View, Button } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import Title from "../components/Title";
import Colors from "../constants/colors";

function ReviewScreen(props) {
  const insets = useSafeAreaInsets();

  // Calculate sales tax (6%)
  const tax = (props.price * 0.06).toFixed(2);
  const finalTotal = (parseFloat(props.price) + parseFloat(tax)).toFixed(2);

  return (
    <View
      style={[
        styles.rootContainer,
        {
          paddingTop: insets.top,
          paddingBottom: insets.bottom,
          paddingLeft: insets.left,
          paddingRight: insets.right,
        },
      ]}
    >
      <View style={styles.titleContainer}>
        <Title>Order Summary</Title>
      </View>

      <View style={styles.subTitleContainer}>
        <Text style={styles.subTitle}>
          Your order has been placed with your order details below
        </Text>
      </View>

      <View style={styles.ingredientsContainer}>
        <Text style={styles.ingredient}>Selected Bicycle Services:</Text>
      </View>

      <View style={styles.summaryContainer}>
        <Text style={styles.summaryText}>
          Subtotal: ${props.price.toFixed(2)}
        </Text>
        <Text style={styles.summaryText}>Sales Tax (6%): ${tax}</Text>
        <Text style={styles.summaryText}>Final Total: ${finalTotal}</Text>
      </View>

      <View style={styles.buttonContainer}>
        <Button title="Return Home" onPress={props.onNext} />
      </View>
    </View>
  );
}

export default ReviewScreen;

const styles = StyleSheet.create({
  rootContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 20,
  },
  titleContainer: {
    marginBottom: 20,
  },
  subTitleContainer: {
    marginBottom: 10,
  },
  subTitle: {
    fontSize: 16,
    textAlign: "center",
  },
  serviceContainer: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: Colors.primary500,
    marginVertical: 5,
  },
  detail: {
    fontSize: 16,
    color: Colors.primary500,
    marginVertical: 3,
  },
  summaryContainer: {
    marginTop: 20,
    alignItems: "center",
  },
  summaryText: {
    fontSize: 16,
    color: Colors.primary500,
  },
  buttonContainer: {
    marginTop: 20,
  },
});
