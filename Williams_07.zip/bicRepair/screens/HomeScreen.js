import { Text, View, StyleSheet, ScrollView, Switch } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Title from "../components/Title";
import { RadioGroup } from "react-native-radio-buttons-group";
import NavButton from "../components/NavButton";
import Colors from "../constants/colors";
import BouncyCheckBox from "react-native-bouncy-checkbox";

function HomeScreen(props) {
  // Set Safe Area Screen Boundaries
  const insets = useSafeAreaInsets();

  return (
    <View
      style={[
        styles.rootContainer,
        {
          paddingTop: insets.top,
          paddingBottom: insets.bottom,
          paddingLeft: insets.left,
          paddingRight: insets.right,
        },
      ]}
    >
      <View style={styles.titleContainer}>
        <Title>Service Pro</Title>
      </View>

      <ScrollView style={styles.scrollContainer}>
        <View style={styles.sectionContainer}>
          <Text style={styles.sectionHeader}>Service Time:</Text>
          <RadioGroup
            radioButtons={props.serviceTimeRadioButtons}
            onPress={props.onSetServiceTime}
            selectedId={props.serviceTimeId}
            layout="column"
            containerStyle={styles.radioGroup}
            labelStyle={styles.radioGroupLabels}
          />
        </View>

        <View style={styles.sectionContainer}>
          <Text style={styles.sectionHeader}>Service Options:</Text>
          <View style={styles.checkboxGroup}>
            {props.serviceOptions.map((item) => (
              <BouncyCheckBox
                key={item.id}
                text={`${item.name} ($${item.price})`}
                isChecked={props.selectedServices.includes(item.id)}
                onPress={() => props.onToggleService(item.id)}
                textStyle={{
                  textDecorationLine: "none",
                  color: Colors.primary500,
                }}
                innerIconStyle={{
                  borderRadius: 0,
                  borderColor: Colors.primary500,
                }}
                iconStyle={{
                  borderRadius: 0,
                }}
                fillColor={Colors.primary500}
                style={{
                  paddingVertical: 5,
                }}
              />
            ))}
          </View>
        </View>

        <View style={styles.sectionContainer}>
          <Text style={styles.sectionHeader}>Additional Options:</Text>
          <View style={styles.switchGroup}>
            <View style={styles.switchItem}>
              <Text style={styles.switchLabel}>Newsletter Signup</Text>
              <Switch
                onValueChange={props.onToggleNewsletterSignup}
                value={props.newsletterSignup}
                thumbColor={
                  props.newsletterSignup ? Colors.primary500 : Colors.primary800
                }
                trackColor={{
                  false: Colors.primary500,
                  true: Colors.primary800,
                }}
              />
            </View>
            <View style={styles.switchItem}>
              <Text style={styles.switchLabel}>Rental Membership ($100)</Text>
              <Switch
                onValueChange={props.onToggleRentalMembership}
                value={props.rentalMembership}
                thumbColor={
                  props.rentalMembership ? Colors.primary500 : Colors.primary800
                }
                trackColor={{
                  false: Colors.primary500,
                  true: Colors.primary800,
                }}
              />
            </View>
          </View>
        </View>

        <View style={styles.buttonContainer}>
          <NavButton onNext={props.onNext}>Submit Order</NavButton>
        </View>
      </ScrollView>
    </View>
  );
}

export default HomeScreen;

const styles = StyleSheet.create({
  rootContainer: {
    flex: 1,
    backgroundColor: Colors.accent500,
    alignItems: "center",
  },
  titleContainer: {
    marginBottom: 20,
    borderWidth: 2,
    borderRadius: 5,
    borderColor: Colors.primary500,
    paddingHorizontal: 15,
    paddingVertical: 10,
    backgroundColor: Colors.primary100,
  },
  scrollContainer: {
    flex: 1,
    width: "90%",
  },
  sectionContainer: {
    marginBottom: 20,
  },
  sectionHeader: {
    fontSize: 24,
    color: Colors.primary500,
    marginBottom: 10,
    fontWeight: "bold",
    textAlign: "center",
  },
  radioGroup: {},
  radioGroupLabels: {
    fontSize: 18,
    color: Colors.primary500,
    marginBottom: 5,
  },
  checkboxGroup: {},
  switchGroup: {
    marginTop: 10,
  },
  switchItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  switchLabel: {
    fontSize: 18,
    color: Colors.primary500,
  },
  buttonContainer: {
    alignItems: "center",
    marginTop: 10,
    marginBottom: 30,
  },
});
