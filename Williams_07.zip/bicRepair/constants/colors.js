const Colors = {
  accent500: "#71797e", // Light Blue
  primary300: "#f0f0f0", // Soft Gray
  primary500: "#ffffff", // Vivid Red
  primary800: "#2c3e50",
};

export default Colors;
