import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";

import { StyleSheet, Text, View, Button } from "react-native";
import { useState, useMemo } from "react";
import Colors from "./constants/colors";
import HomeScreen from "./screens/HomeScreen";
import ReviewScreen from "./screens/ReviewScreen";

export default function App() {
  const [currentScreen, setCurrentScreen] = useState("home");
  const [currentPrice, setCurrentPrice] = useState(0);

  const [serviceTimeId, setServiceTimeId] = useState(0);
  const [selectedServices, setSelectedServices] = useState([]);
  const [newsletterSignup, setNewsletterSignup] = useState(false);
  const [rentalMembership, setRentalMembership] = useState(false);

  const serviceTimeRadioButtons = useMemo(
    () => [
      {
        id: "0",
        label: "Standard ($0)",
        value: "Standard",
        price: 0,
        borderColor: Colors.primary500,
        color: Colors.primary500,
      },
      {
        id: "1",
        label: "Expedited ($50)",
        value: "Expedited",
        price: 50,
        borderColor: Colors.primary500,
        color: Colors.primary500,
      },
      {
        id: "2",
        label: "Next Day ($100)",
        value: "Next Day",
        price: 100,
        borderColor: Colors.primary500,
        color: Colors.primary500,
      },
    ],
    []
  );

  const serviceOptions = useMemo(
    () => [
      { id: 0, name: "Basic Tune-Up", price: 50 },
      { id: 1, name: "Comprehensive Tune-Up", price: 75 },
      { id: 2, name: "Flat Tire Repair", price: 20 },
      { id: 3, name: "Brake Servicing", price: 50 },
      { id: 4, name: "Gear Servicing", price: 40 },
      { id: 5, name: "Chain Servicing", price: 15 },
      { id: 6, name: "Frame Repair", price: 35 },
      { id: 7, name: "Safety Check", price: 25 },
      { id: 8, name: "Accessory Install", price: 10 },
    ],
    []
  );

  function setServiceTimeHandler(id) {
    setServiceTimeId(id);
  }

  function toggleService(id) {
    setSelectedServices((prevServices) =>
      prevServices.map((serviceId) =>
        serviceId === id ? serviceId : serviceId
      )
    );
  }

  function toggleNewsletterSignup() {
    setNewsletterSignup((previous) => !previous);
  }

  function toggleRentalMembership() {
    setRentalMembership((previous) => !previous);
  }

  function homeScreenHandler() {
    setCurrentPrice(0);
    setCurrentScreen("home");
  }

  function ReviewHandler() {
    let price = serviceTimeRadioButtons[serviceTimeId].price;
    selectedServices.forEach((serviceId) => {
      price += serviceOptions[serviceId].price;
    });

    if (rentalMembership) {
      price += 100;
    }

    setCurrentPrice(price);
    setCurrentScreen("review");
  }

  let screen = (
    <HomeScreen
      serviceTimeId={serviceTimeId}
      selectedServices={selectedServices}
      newsletterSignup={newsletterSignup}
      rentalMembership={rentalMembership}
      serviceTimeRadioButtons={serviceTimeRadioButtons}
      serviceOptions={serviceOptions}
      onSetServiceTime={setServiceTimeHandler}
      onToggleService={toggleService}
      onToggleNewsletterSignup={toggleNewsletterSignup}
      onToggleRentalMembership={toggleRentalMembership}
      onNext={ReviewHandler}
    />
  );

  if (currentScreen === "review") {
    screen = (
      <ReviewScreen
        serviceTime={serviceTimeRadioButtons[serviceTimeId].value}
        services={selectedServices}
        serviceOptions={serviceOptions}
        newsletterSignup={newsletterSignup}
        rentalMembership={rentalMembership}
        price={currentPrice}
        onNext={homeScreenHandler}
      />
    );
  }

  return (
    <>
      <StatusBar style="light" />
      <SafeAreaProvider style={styles.container}>{screen}</SafeAreaProvider>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.accent500,
    alignItems: "center",
    justifyContent: "center",
  },
});
