import { useLayoutEffect } from "react";
import { View, Text, FlatList } from "react-native";
import DesItem from "../components/DesItem";
import { DESTINATIONS, COUNTRIES } from "../data/dummy-data";

function VacDesOverviewScreen(props) {
  const countryId = props.route.params.countryId;

  useLayoutEffect(() => {
    const country = COUNTRIES.find((country) => country.id === countryId);
    props.navigation.setOptions({ title: country ? country.name : null });
  }, [countryId, props.navigation]);

  const displayedDestinations = DESTINATIONS.filter((destination) => {
    return destination.countryId === countryId;
  });

  function renderDestinationItem(itemData) {
    const destinationItemProps = {
      name: itemData.item.name,
      imageUrl: itemData.item.imageUrl,
      avgCost: itemData.item.avgCost,
      foundedYear: itemData.item.foundedYear,
      desc: itemData.item.desc,
      rating: itemData.item.rating,
      listIndex: itemData.index,
    };
    return <DesItem {...destinationItemProps} />;
  }

  return (
    <View>
      <FlatList
        data={displayedDestinations}
        keyExtractor={(item) => item.id}
        renderItem={renderDestinationItem}
      />
    </View>
  );
}

export default VacDesOverviewScreen;
