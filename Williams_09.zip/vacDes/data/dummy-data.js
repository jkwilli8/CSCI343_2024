import Countries from "../models/countries";
import Destinations from "../models/destinations";

export const COUNTRIES = [
  new Countries("c1", "France", "#ff4757"), // Red
  new Countries("c2", "Italy", "#1e90ff"), // Blue
  new Countries("c3", "Spain", "#2ed573"), // Green
  new Countries("c4", "United States", "#ff6b81"), // Orange
  new Countries("c5", "Japan", "#a29bfe"), // Purple
  new Countries("c6", "Thailand", "#ffeaa7"), // Yellow
  new Countries("c7", "Australia", "#74b9ff"), // Blue
  new Countries("c8", "Greece", "#55efc4"), // Green
  new Countries("c9", "Mexico", "#ff7675"), //  Red
  new Countries("c10", "Canada", "#6c5ce7"), //  Purple
];

export const DESTINATIONS = [
  // France
  new Destinations(
    "d1",
    "c1",
    "Paris",
    2000,
    1780,
    "The romantic capital of the world, known for its iconic Eiffel Tower.",
    4.9,
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS1MvsToegWW-7ot4pHjfwhR-zswok-D6Pl8g&s"
  ),
  new Destinations(
    "d2",
    "c1",
    "Nice",
    1500,
    1860,
    "A beautiful coastal city along the French Riviera.",
    4.7,
    "https://images.ctfassets.net/i3kf1olze1gn/1ITrM0F1evQj3nGmG77x6N/92126253daad46b68c401ef17928f045/villefranche-sur-mer.jpg?q=55&w=640"
  ),

  // Italy
  new Destinations(
    "d3",
    "c2",
    "Rome",
    1800,
    753,
    "The Eternal City, home to the ancient Roman Empire's wonders like the Colosseum.",
    4.8,
    "https://i.natgeofe.com/k/a6c9f195-de20-445d-9d36-745ef56042c5/OG_Colosseum_Ancient-Rome_KIDS_1122_3x2.jpg"
  ),
  new Destinations(
    "d4",
    "c2",
    "Venice",
    1600,
    421,
    "A floating city built on canals, offering gondola rides.",
    4.6,
    "https://www.fodors.com/wp-content/uploads/2023/06/0-HERO-istockphoto-1388018793.jpg"
  ),

  // Spain
  new Destinations(
    "d5",
    "c3",
    "Barcelona",
    1700,
    133,
    "A city renowned for its unique architecture.",
    4.7,
    "https://www.spain.info/.content/imagenes/cabeceras-grandes/cataluna/park-guell-barcelona-s-305364611.jpg"
  ),
  new Destinations(
    "d6",
    "c3",
    "Madrid",
    1400,
    852,
    "Spain's capital, known for its royal palace, and world-class museums.",
    4.5,
    "https://www.spain.info/.content/imagenes/cabeceras-grandes/madrid/calle-gran-via-madrid-s333961043.jpg"
  ),

  // United States
  new Destinations(
    "d7",
    "c4",
    "New York City",
    2500,
    1624,
    "The city that never sleeps, famous for Times Square, Central Park, and the Statue of Liberty.",
    4.8,
    "https://cdn.britannica.com/61/93061-050-99147DCE/Statue-of-Liberty-Island-New-York-Bay.jpg"
  ),
  new Destinations(
    "d8",
    "c4",
    "San Francisco",
    2300,
    1776,
    "Known for the Golden Gate Bridge, its steep streets, and the historic Alcatraz Island.",
    4.7,
    "https://upload.wikimedia.org/wikipedia/commons/thumb/6/61/San_Francisco_from_the_Marin_Headlands_in_August_2022.jpg/290px-San_Francisco_from_the_Marin_Headlands_in_August_2022.jpg"
  ),

  // Japan
  new Destinations(
    "d9",
    "c5",
    "Tokyo",
    2200,
    1457,
    "A bustling metropolis blending ultramodern technology with ancient temples and shrines.",
    4.9,
    "https://images.goway.com/production/featured_images/japan_tokyo_akihabara_AdobeStock_295310062_Editorial_Use_Only.jpg"
  ),
  new Destinations(
    "d10",
    "c5",
    "Kyoto",
    1800,
    794,
    "The cultural heart of Japan, famous for its classical Buddhist temples, and gardens.",
    4.8,
    "https://content.r9cdn.net/rimg/dimg/83/d4/85f68013-city-20339-16489ec9b8b.jpg?crop=true&width=1020&height=498"
  ),

  // Thailand
  new Destinations(
    "d11",
    "c6",
    "Bangkok",
    1200,
    1782,
    "Thailand's capital, known for its vibrant street life and ornate temples.",
    4.6,
    "https://quintessentially.com/assets/noted/Header_2023-04-12-154210_sigz.webp"
  ),
  new Destinations(
    "d12",
    "c6",
    "Phuket",
    1100,
    1825,
    "A popular island destination with clear blue waters, white sandy beaches.",
    4.7,
    "https://www.letsphuket.com/wp-content/uploads/phuket1.jpg"
  ),

  // Australia
  new Destinations(
    "d13",
    "c7",
    "Sydney",
    2000,
    1788,
    "Australia’s largest city, known for the iconic Sydney Opera House and the stunning Sydney Harbour.",
    4.8,
    "https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Sydney_Opera_House_and_Harbour_Bridge_Dusk_%282%29_2019-06-21.jpg/800px-Sydney_Opera_House_and_Harbour_Bridge_Dusk_%282%29_2019-06-21.jpg"
  ),
  new Destinations(
    "d14",
    "c7",
    "Melbourne",
    1700,
    1835,
    "Famed for its vibrant arts scene, diverse culinary options, and its unique blend of modern and Victorian architecture.",
    4.7,
    "https://upload.wikimedia.org/wikipedia/commons/7/74/Melbourne_skyline_sor.jpg"
  ),

  // Greece
  new Destinations(
    "d15",
    "c8",
    "Athens",
    1500,
    3000,
    "The birthplace of democracy and philosophy.",
    4.9,
    "https://cdn.britannica.com/66/102266-050-FBDEFCA1/acropolis-city-state-Greece-Athens.jpg"
  ),
  new Destinations(
    "d16",
    "c8",
    "Santorini",
    1200,
    900,
    "A picturesque island famous for its whitewashed buildings, blue-domed churches, and stunning sunsets.",
    4.8,
    "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTeC7JsRsN8rxHmtJAV3Y6udRu6o4qs_7oRSQ&s"
  ),

  // Mexico
  new Destinations(
    "d17",
    "c9",
    "Cancun",
    1300,
    1970,
    "A tropical paradise known for its pristine beaches, luxury resorts, and vibrant nightlife.",
    4.6,
    "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d8/Cancun_Strand_Luftbild_%2822143397586%29.jpg/1200px-Cancun_Strand_Luftbild_%2822143397586%29.jpg"
  ),
  new Destinations(
    "d18",
    "c9",
    "Mexico City",
    1400,
    1325,
    "The capital of Mexico, rich with history, art, and stunning architecture.",
    4.5,
    "https://i.natgeofe.com/n/73d9e4e3-4884-4e93-ac41-6be6a90079f5/mexico-city-travel%20(1).jpg?w=2880&h=1920"
  ),

  // Canada
  new Destinations(
    "d19",
    "c10",
    "Toronto",
    2000,
    1793,
    "A bustling multicultural city, home to the CN Tower and the scenic waterfront of Lake Ontario.",
    4.7,
    "https://cdn.britannica.com/35/100235-050-CE3936EE/view-CN-Tower-Toronto-skyline-observation-deck.jpg"
  ),
  new Destinations(
    "d20",
    "c10",
    "Vancouver",
    1900,
    1886,
    "Surrounded by mountains and ocean, this city is a haven for outdoor enthusiasts.",
    4.8,
    "https://upload.wikimedia.org/wikipedia/commons/5/57/Concord_Pacific_Master_Plan_Area.jpg"
  ),
];
