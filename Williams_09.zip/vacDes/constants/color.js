const Colors = {
  accent300: "rgb(255, 165, 0)",
  accent300o75: "rgba(255, 165, 0, 0.75)",
  accent500: "rgb(34, 193, 195)",
  accent800: "rgb(252, 3, 3)",
  primary300: "rgb(255, 239, 0)",
  primary500: "rgb(0, 204, 68)",
  primary800: "rgb(128, 128, 128)",
};

export default Colors;
