class Destinations {
  constructor(
    id,
    countryId,
    name,
    avgCost,
    foundedYear,
    desc,
    rating,
    imageUrl
  ) {
    this.id = id;
    this.countryId = countryId;
    this.name = name;
    this.avgCost = avgCost;
    this.foundedYear = foundedYear;
    this.desc = desc;
    this.rating = rating;
    this.imageUrl = imageUrl;
  }

  toString() {
    return `${this.name} was founded in ${this.foundedYear} 
    and has a average cost of ${this.avgCost} 
    - Short description: ${this.desc}, Rating: ${this.rating}`;
  }
}

export default Destinations;
