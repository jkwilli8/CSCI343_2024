const Colors = {
  accent300: "#6CAACD", // Light Sky Blue
  accent500: "#007BA7",
  primary300o5: "rgba(244, 164, 96, 0.5)", // Sandy Brown with 50% opacity
  primary300: "#F4A460", // Sandy Brown
  primary500: "#CD853F", // Peru
  primary800: "#8B4513", //
};

export default Colors;
