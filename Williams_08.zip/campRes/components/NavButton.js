import {
  Pressable,
  View,
  StyleSheet,
  Text,
  useWindowDimensions,
} from "react-native";
import Colors from "../constants/color";

function NavButton(props) {
  const { width, height } = useWindowDimensions();

  return (
    <Pressable
      android_ripple={{ color: "grey" }}
      onPress={props.onNext}
      style={({ pressed }) => pressed && styles.pressedItem}
    >
      <View style={styles.buttonContainer}>
        <View style={styles.imageContainer}>
          <Text style={[styles.text, { fontSize: width * 0.07 }]}>
            {props.children}
          </Text>
        </View>
      </View>
    </Pressable>
  );
}

export default NavButton;

const styles = StyleSheet.create({
  buttonContainer: {
    justifyContent: "center",
    alignItems: "center",
    borderRadius: 6,
    borderColor: Colors.accent500,
    backgroundColor: Colors.primary500,
    height: 75,
    width: 1000,
    maxWidth: "70%",
    marginHorizontal: 10,
    marginVertical: 10,
    borderRadius: 50,
  },
  pressedItem: {
    opacity: 0.5,
  },
  imageContainer: {},
  text: {
    padding: 2,
    paddingBottom: 8,
    textAlign: "center",
    color: Colors.primary800,
    fontFamily: "camp",
  },
});
