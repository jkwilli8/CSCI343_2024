const Colors = {
  accent300: "rgb(13, 71, 161)",
  accent300o75: "rgba(13, 71, 161, 0.75)",
  accent500: "rgb(0, 57, 115)",
  accent800: "rgb(0, 0, 0)",
  primary300: "rgb(97, 97, 97)",
  primary500: "rgb(66, 66, 66)",
  primary800: "rgb(33, 33, 33)",
};

export default Colors;
