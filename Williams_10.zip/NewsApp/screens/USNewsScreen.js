import { View, Text } from "react-native";

function USNewsScreen() {
  return (
    <View>
      <Text>U.S News Screen </Text>
    </View>
  );
}

export default USNewsScreen;
