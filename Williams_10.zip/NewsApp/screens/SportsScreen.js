import { View, Text } from "react-native";

function SportsScreen() {
  return (
    <View>
      <Text>Sports Screen</Text>
    </View>
  );
}

export default SportsScreen;
