import { View, Text } from "react-native";

function WorldNewsScreen() {
  return (
    <View>
      <Text>World News Screen </Text>
    </View>
  );
}

export default WorldNewsScreen;
