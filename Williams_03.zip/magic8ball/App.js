import { StatusBar } from "expo-status-bar";
import { useState } from "react";
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  Button,
  Modal,
  TextInput,
} from "react-native";

// random responses
const responses = [
  "It is certain",
  "It is decidedly so",
  "Without a doubt",
  "Yes definitely",
  "You may rely on it",
  "As I see it, yes",
  "Most likely",
  "Outlook good",
  "Yes",
  "Signs point to yes",
  "Reply hazy, try again",
  "Ask again later",
  "Better not tell you now",
  "Cannot predict now",
  "Concentrate and ask again",
  "Don't count on it",
  "My reply is no",
  "My sources say no",
  "Outlook not so good",
  "Very doubtful",
];

export default function App() {
  // User's question
  const [question, setQuestion] = useState("");
  // response form 8 ball
  const [response, setResponce] = useState(1);
  // Modal visibility state
  const [modalIsVisible, setModalIsVisible] = useState(false);

  //function for sumbmiting
  function userQuestion() {
    if (question.trim()) {
      const rndResponse =
        responses[Math.floor(Math.random() * responses.length)];
      setResponce(rndResponse);
      setModalIsVisible(true);
    }
  }

  // function to end 8 ball
  function endMagicEightBall() {
    setModalIsVisible(false);
  }

  return (
    <>
      <StatusBar style="auto" />
      <SafeAreaView style={styles.root}>
        <View style={styles.titleContainer}>
          <Text style={styles.title}> Magic Eight Ball</Text>
        </View>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.TextInput}
            placeholder="Please enter your question"
            value={question}
            onChangeText={setQuestion}
          />
          <Button title="Submit" onPress={userQuestion} />
        </View>

        <Modal visible={modalIsVisible} animationType="slide">
          <SafeAreaView style={styles.modalRoot}>
            <Text style={styles.modalTitle}>Your Question:</Text>
            <Text style={styles.modalText}>{question}</Text>
            <Text style={styles.modalTitle}>The Magic Eight Ball Says:</Text>
            <Text style={styles.modalText}>{response}</Text>

            <Button title="Close" onPress={endMagicEightBall} />
          </SafeAreaView>
        </Modal>
      </SafeAreaView>
    </>
  );
}

//style sheet
const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "#71797E",
    alignItems: "center",
    justifyContent: "center",
  },
  titleContainer: {
    marginBottom: 20,
  },

  title: {
    fontSize: 40,
    color: "black",
    textAlign: "center",
  },
  inputContainer: {
    width: "80%",
    alignItems: "center",
    marginBottom: 20,
  },
  TextInput: {
    width: "100%",
    padding: 10,
    borderColor: "white",
    borderWidth: 2,
    marginBottom: 15,
    borderRadius: 5,
  },
  modalRoot: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#71797E",
  },
  modalTitle: {
    fontSize: 24,
    marginBottom: 10,
  },
  modalText: {
    fontSize: 18,
    marginBottom: 20,
  },
});
