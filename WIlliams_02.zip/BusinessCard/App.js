import { StatusBar } from "expo-status-bar";
import {
  SafeAreaView,
  StyleSheet,
  Text,
  View,
  Image,
  Linking,
} from "react-native";

export default function App() {
  return (
    <>
      <StatusBar style="auto" />
      <SafeAreaView style={styles.root}>
        <View style={styles.imageContainer}>
          <Image
            style={styles.image}
            source={require("./assets/images/me.jpeg")}
          />
        </View>
        <View style={styles.infoContainer}>
          <Text style={styles.name}>Jabbar Williams</Text>
          <Text
            style={styles.text}
            onPress={() => {
              Linking.openURL("mailto:jkwilli8@coastal.edu");
            }}
          >
            jkwilli8@coastal.edu
          </Text>
          <Text
            style={styles.text}
            onPress={() => {
              Linking.openURL("tel:6782660835");
            }}
          >
            6782660835
          </Text>
          <Text
            style={styles.text}
            onPress={() => {
              Linking.openURL("https://github.com/jkwilli8/CSCI343_2024");
            }}
          >
            https://github.com/jkwilli8/CSCI343_2024
          </Text>
        </View>
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: "#71797E",
    alignItems: "center",
    justifyContent: "center",
  },
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  imageContainer: {
    flex: 2,
    marginTop: 100,
    width: "100%",
  },
  image: {
    height: 300,
    width: "100%",
    resizeMode: "cover",
    backgroundColor: "white",
    borderWidth: 3,
    borderColor: "white",
  },
  infoContainer: {
    flex: 2,
    width: "100%",
    alignItems: "center",
  },
  name: {
    fontSize: 35,
    textAlign: "center",
    color: "black",
    fontWeight: "bold",
    marginBottom: 40,
  },
  text: {
    fontSize: 20,
    color: "white",
    fontStyle: "italic",
    marginBottom: 10,
  },
});
